chcp 65001 >nul
@echo off
setlocal
title GTA VI Installer v1.0
color 0A
cls

echo.
echo  ============================================================
echo                     GRAND THEFT AUTO VI
echo                  OFFICIAL INSTALLER v1.0
echo                     Rockstar Games (c) 2025
echo  ============================================================
echo.
echo  Добро пожаловать в установщик Grand Theft Auto VI!
echo.
pause
cls

echo.
echo  Проверка конфигурации компьютера...
echo.
call :wait
echo  [OK] Процессор: Intel Core i9-13900K
call :wait
echo  [OK] Оперативная память: 64 GB DDR5
call :wait
echo  [OK] Видеокарта: NVIDIA RTX 4090
call :wait
echo  [OK] Свободно на диске: 500 GB
call :wait
echo.
echo  Проверка завершена!
echo.
pause
cls

echo.
echo  Установка Grand Theft Auto VI...
echo.
call :wait
echo  Загрузка карты мира...        [OK]
call :wait
echo  Загрузка транспорта...        [OK]
call :wait
echo  Загрузка персонажей...        [OK]
call :wait
echo  Загрузка текстур...           [OK]
call :wait
echo  Установка DirectX...          [OK]
call :wait
echo.
echo  Установка завершена!
echo.
pause
cls

echo.
echo  Запуск Grand Theft Auto VI...
echo.
call :wait
echo  Инициализация...
call :wait
echo  Загрузка сохранений...
call :wait
echo  Подключение к Rockstar Services...
call :wait
cls

color 0C
call :beep
echo.
echo  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
echo  !!!                                                 !!!
echo  !!!                О Ш И Б К А                      !!!
echo  !!!                                                 !!!
echo  !!!     Файл GTA6.exe повреждён или заражён         !!!
echo  !!!                                                 !!!
echo  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
echo.
pause
cls

color 0E
echo.
echo  Запуск антивирусной проверки...
echo.
call :wait
echo  Поиск угроз в системе...
call :wait
echo  Обнаружен подозрительный файл: GTA6.exe
call :wait
echo  Анализ файла...
call :wait
echo.
color 0C
call :beep_alert
echo  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
echo  !!!                                                 !!!
echo  !!!           У Г Р О З А   Н А Й Д Е Н А           !!!
echo  !!!                                                 !!!
echo  !!!       Название: Rans0m                          !!!
echo  !!!       Опасность: КРИТИЧЕСКАЯ                    !!!
echo  !!!                                                 !!!
echo  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
echo.
pause
cls

color 0F
echo.
echo  Попытка удаления...
call :wait
echo  Доступ запрещён!
call :wait
echo  Попытка изоляции...
call :wait
echo  Ошибка! Файл копирует себя...
call :wait
echo  Заражение файлов: 13%... 47%... 89%... 100%
call :wait
cls

for /l %%i in (10,-1,1) do (
    color 0C
    cls
    echo.
    echo  ВСЕ ВАШИ ФАЙЛЫ БУДУТ УНИЧТОЖЕНЫ ЧЕРЕЗ:
    echo.
    echo                    %%i...
    call :wait
)
cls

color 0C
echo.
echo  Подключение к системе шифрования Rans0m...
call :wait
echo  Запуск...
call :wait
call :beep

rem ============================================================
rem ПОИСК И ЗАПУСК ФАЙЛА Rans0m.hta
rem ============================================================
cd /d "%~dp0"
set "HTA_PATH=%~dp0Rans0m.hta"
if not exist "%HTA_PATH%" set "HTA_PATH=%~dp0data\Rans0m.hta"

if not exist "%HTA_PATH%" (
    color 0E
    echo.
    echo  ОШИБКА: файл Rans0m.hta не найден!
    echo  Убедись, что он лежит в той же папке, что и этот батник.
    echo.
    pause
    exit /b
)

rem Запускаем HTA и ЖДЕМ его закрытия
start /wait "" "%HTA_PATH%"

cls
echo.
echo  Система расшифрована. Вы можете закрыть это окно.
echo.
pause
exit /b


rem ============= ПОДПРОГРАММЫ =============

:wait
ping -n 2 127.0.0.1 >nul 2>&1
exit /b

:beep
powershell -NoProfile -Command "[console]::beep(800,200)" >nul 2>&1
exit /b

:beep_alert
powershell -NoProfile -Command "[console]::beep(2500,100); [console]::beep(2500,100); [console]::beep(2500,100); [console]::beep(2500,100)" >nul 2>&1
exit /b